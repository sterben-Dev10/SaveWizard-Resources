patcher.exe ValkyrieElysuim.savepatch 3,4 ue4savegame.ps4.sav
call rainbow2.bat
pause
