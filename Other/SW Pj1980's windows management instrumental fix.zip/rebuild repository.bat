winmgmt /salvagerepository
pause