winmgmt /resetrepository
pause