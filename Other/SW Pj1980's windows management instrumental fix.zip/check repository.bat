winmgmt /verifyrepository
pause